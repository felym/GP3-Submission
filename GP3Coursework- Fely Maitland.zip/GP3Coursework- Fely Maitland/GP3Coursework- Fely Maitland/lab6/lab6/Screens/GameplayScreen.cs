#region Using Statements
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
#endregion

namespace lab6
{
    class GameplayScreen : GameScreen
    {
        #region User Defined Variables

        SpriteBatch spriteBatch;
        ContentManager Content;
        SpriteFont fontToUse;

        Song bkgMusic;
        SoundEffect footstep;
        SoundEffect collisionSound;
        SoundEffect hurtSound;
        SoundEffectInstance collsionSoundInstance;
        SoundEffectInstance footstepInstance;
        SoundEffectInstance hurtSoundInstance;

        KeyboardState keyState;
        KeyboardState prevkeyState;

        //The keys are all active at the start
        bool keyActive = true;
        //Set the music not to be muted at the start
        bool paused = false;

        //Variables for the models
        //player
        private Model mdlChar;
        private Matrix[] mdlCharTransforms;
        //monster
        private Model mdlMonster;
        private Vector3 mdlMonsterPos = new Vector3(-260, -90, 560);
        private Matrix[] mdlMonsterTransforms;
        //SeaMonster
        private Model mdlSeaMonster;
        private Vector3 mdlSeaMonsterPos = new Vector3(-1160, -80, -250);
        private Matrix[] mdlSeaMonsterTransforms;
        //Bug
        private Model mdlBug;
        private Vector3 mdlBugPos = new Vector3(-400, -80, -800);
        private Matrix[] mdlBugTransforms;
        //three armed monster
        private Model mdlThreeArms;
        private Vector3 mdlThreeArmsPos = new Vector3(120, -80, -80);
        private Matrix[] mdlThreeArmsTransforms;
        //ground
        private Model mdlGround;
        private Matrix[] mdlGroundTransforms;
        //trapdoor
        private Model mdlTrapdoor;
        private Matrix[] mdlTrapdoorTransforms;
        //walls
        private Model mdlWall;
        private Matrix[] mdlWallTransforms;
        private Walls[] wallList = new Walls[GameConstants.numWalls];
        //doorways
        private Model mdlWall3;
        private Matrix[] mdlWall3Transforms;
        private Doors[] doorList = new Doors[GameConstants.numDoors];
        //keys
        private Model mdlKey;
        private Matrix[] mdlKeyTransforms;
        private Key[] keyList = new Key[GameConstants.keyNum];
        //curtains
        private Model mdlCurtain;
        private Matrix[] mdlCurtainTransforms;
        private Curtain[] curtainList = new Curtain[GameConstants.curtainNum];

        // The aspect ratio determines how to scale 3d to 2d projection.
        private float aspectRatio;

        //player
        private Vector3 mdlPosition = new Vector3(0, -30, -20);
        private float mdlRotation = 4.6f;

        //An enum to switch between two cameras
        enum cameras { mainCamera, topDownCamera }
        cameras switchCamera = cameras.mainCamera;

        //Changing the selected camera
        Vector3 cameraSelectedPos;
        public Matrix viewMatrixSelected;
        public Matrix projectionSelected;

        //Third person camera
        Camera camera1;

        //World,view and project matrices for the mouse controlled camera
        Matrix worldMatrix;
        Matrix viewMatrix;
        Matrix projectionMatrix;

        //Variables for the mouse controlled camera
        Vector3 cameraPosition = new Vector3(-400, 90, 15);
        float leftrightRot = MathHelper.PiOver2;
        float updownRot = -MathHelper.Pi / 10.0f;
        const float rotationSpeed = 0.3f;
        const float moveSpeed = 30.0f;
        MouseState originalMouseState;
        GamePadState originalGamePadState;
        public Vector3 cameraOffset = new Vector3(0.0f, 80.0f, -50.0f);
        public Vector3 newCamPos;

        //The player starts with no keys collected
        int keyCollectGame = 0;
        //Player starts at full health
        float playerHealth = 100;

        #endregion

        public GameplayScreen()
        {
            //Smooth the Transition between screens
            TransitionOnTime = TimeSpan.FromSeconds(1.5);
            TransitionOffTime = TimeSpan.FromSeconds(0.5);
        }

        //This method initialises all of the positions and rotations for the lists of objects
        private void initializeModels()
        {
            //room one walls
            //left
            wallList[0].position = new Vector3(140, -70, -420);
            //right
            wallList[1].position = new Vector3(210, -70, 250);
            //backwall
            wallList[2].position = new Vector3(460, -70, -80);
            wallList[2].rotation = -1.58f;

            //room two walls
            //backwall
            wallList[3].position = new Vector3(-400, -70, 800);
            //left
            wallList[4].position = new Vector3(-150, -70, 600);
            wallList[4].rotation = -1.58f;
            //right
            wallList[5].position = new Vector3(-700, -70, 600);
            wallList[5].rotation = -1.58f;

            //room three walls
            //right
            wallList[6].position = new Vector3(-1105, -70, -390);
            //left
            wallList[7].position = new Vector3(-1095, -70, 250);
            //backwall
            wallList[8].position = new Vector3(-1300, -70, -80);
            wallList[8].rotation = -1.58f;

            //room four walls
            //backwall
            wallList[9].position = new Vector3(-400, -70, -850);
            //right
            wallList[10].position = new Vector3(-150, -70, -755);
            wallList[10].rotation = -1.58f;
            //left
            wallList[11].position = new Vector3(-700, -70, -755);
            wallList[11].rotation = -1.58f;

            //keys
            for (int k = 0; k < keyList.Length; k++)
            {
                keyList[k].isActive = true;
            }
            keyList[0].position = new Vector3(-1195, -70, -15);
            keyList[1].position = new Vector3(-650, -70, 600);
            keyList[2].position = new Vector3(395, -70, 0);
            keyList[3].position = new Vector3(-195, -70, -600);

            //doorways
            //room behind doorway
            doorList[0].position = new Vector3(-102, -135, -50);
            doorList[0].rotation = -1.555f;
            //room right doorway
            doorList[1].position = new Vector3(-465, -135, -422);
            //room left doorway
            doorList[2].position = new Vector3(-450, -135, 220);
            //room front doorway
            doorList[3].position = new Vector3(-705, -135, 0);
            doorList[3].rotation = -1.555f;

            //curtains
            //room left curtain
            curtainList[0].position = new Vector3(-495, -60, 210);
            //room behind curtain
            curtainList[1].position = new Vector3(-100, -60, -95);
            curtainList[1].rotation = -1.55f;
            //room right curtain
            curtainList[2].position = new Vector3(-512, -60, -425);
            //room infront curtain
            curtainList[3].position = new Vector3(-695, -60, -45);
            curtainList[3].rotation = -1.55f;
        }

        //Initialises the third person camera and selects the camera on start up
        private void InitializeCamera()
        {
            camera1 = new Camera(ScreenManager.GraphicsDevice.Viewport);
            camera1.CamPosition = mdlPosition + new Vector3(0, 0, 0);
            camera1.CamRotationSpeed = 1f / 60f;
            camera1.Inct = new Vector3(0, 0, 1);
            worldMatrix = Matrix.Identity;

            projectionMatrix = Matrix.CreatePerspectiveFieldOfView(MathHelper.PiOver4, aspectRatio, 0.3f, 1500.0f);//sets up the projection for 1st person
            //the first person camera is selected 
            cameraSelectedPos = cameraPosition;
            viewMatrixSelected = viewMatrix;
            projectionSelected = projectionMatrix;
        }

        //This updates the third person camera
        private void UpdateCamera()
        {
            Matrix rotationMatrix = Matrix.CreateRotationY(mdlRotation);
            Vector3 transformedReference = Vector3.Transform(cameraOffset, rotationMatrix);            
            newCamPos = transformedReference +camera1.CamPosition;
            camera1.CamLookat = mdlPosition +new Vector3(0.0f, 50.0f, 0.0f); //makes the camera always look at the player
            camera1.CamViewMatrix = Matrix.CreateLookAt(newCamPos, camera1.CamLookat, Vector3.Up);
        }

        //Contains all of the keyboard key controls for the game
        private void KeyControls()
        {
            prevkeyState = keyState; //sets the previous keystate to the current keystate
            keyState = Keyboard.GetState();//gets the keystate
            int playerIndex = (int)ControllingPlayer.Value;// Look up inputs for the active player profile

            //If escape or back on the xbox is pressed, load main menu
            if (keyState.IsKeyDown(Keys.Escape) || GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
            {
                LoadingScreen.Load(ScreenManager, true, ControllingPlayer.Value,
               new MainMenuScreen());
            }

            //if keys collected = 4, load main menu
            if (keyCollectGame == 4 )
            {
                LoadingScreen.Load(ScreenManager, true, ControllingPlayer.Value,
                               new MainMenuScreen());
            }

            //If the 'M' is pressed, mute the music, if pressed again, continue playing the music
            if (keyState.IsKeyDown(Keys.M) && prevkeyState != keyState)
            {
                if (paused == true)
                {
                    MediaPlayer.Resume();

                    paused = false;
                }
                else
                {
                    if (paused == false)
                    {
                        MediaPlayer.Pause();
                        paused = true;
                    }
                }
            }
            //If the camera is the first person camera, press the one key to switch to third person and press two to switch back to first
            if (switchCamera == cameras.mainCamera)
            {
                if (keyState.IsKeyDown(Keys.D1) || GamePad.GetState(PlayerIndex.One).Buttons.Y == ButtonState.Pressed)
                {
                    if (switchCamera == cameras.mainCamera)
                    {switchCamera = cameras.topDownCamera;}
                }
            }
            else if (switchCamera == cameras.topDownCamera)
            {
                if (keyState.IsKeyDown(Keys.D2) || GamePad.GetState(PlayerIndex.One).Buttons.B == ButtonState.Pressed)
                {switchCamera = cameras.mainCamera;}
            }

            //If W or S is pressed play the walk sound effect
            if ((keyState.IsKeyDown(Keys.W) && prevkeyState != keyState || keyState.IsKeyDown(Keys.S) && prevkeyState != keyState))
            {
                if (paused == false)
                {
                    footstepInstance.Play();
                }
                prevkeyState = keyState;
            }
            //if W or S is released, stop playing the walking sound effect
            if ((keyState.IsKeyUp(Keys.W) && prevkeyState != keyState || keyState.IsKeyUp(Keys.S) && prevkeyState != keyState))
            { footstepInstance.Stop(); }
        }

        //This method loads all of the content in for the game
        public override void LoadContent()
        {
            //Calls the initialise camera and models at the start
            InitializeCamera();
            initializeModels();
            spriteBatch = new SpriteBatch(ScreenManager.GraphicsDevice);// Create a new SpriteBatch, which can be used to draw the GUI.
            Content = new ContentManager(ScreenManager.Game.Services, "Content"); //Creates a new ContentManager, used to load in assets
            aspectRatio = ScreenManager.GraphicsDevice.Viewport.AspectRatio;//Gets the aspect ratio for the screen
            //Sets the mouse position to be the center of the screen
            Mouse.SetPosition(ScreenManager.GraphicsDevice.Viewport.Width / 2, ScreenManager.GraphicsDevice.Viewport.Height / 2);
            originalMouseState = Mouse.GetState();//Gets the mouse state
            originalGamePadState = GamePad.GetState(PlayerIndex.One);//Gets the xbox controller state

            fontToUse = Content.Load<SpriteFont>("uiFont");//loads the font
            //background audio
            bkgMusic = Content.Load<Song>("Aftermath");
            MediaPlayer.Play(bkgMusic);
            MediaPlayer.IsRepeating = true;
            //collision with key sound
            collisionSound = Content.Load<SoundEffect>("ding");
            collsionSoundInstance = collisionSound.CreateInstance();
            //hurt sound when player collides with monster
            hurtSound = Content.Load<SoundEffect>("ow");
            hurtSoundInstance = hurtSound.CreateInstance();
            //footsteps sound
            footstep = Content.Load<SoundEffect>("footsteps-4");
            footstepInstance = footstep.CreateInstance();
            footstepInstance.IsLooped = true;

            //player model
            mdlChar = Content.Load<Model>(".\\Models\\player4");
            mdlCharTransforms = SetupEffectTransformDefaults(mdlChar);
            //monster model
            mdlMonster = Content.Load<Model>(".\\Models\\goblin");
            mdlMonsterTransforms = SetupEffectTransformDefaults(mdlMonster);
            //SeaMonster model
            mdlSeaMonster = Content.Load<Model>(".\\Models\\seamonster1");
            mdlSeaMonsterTransforms = SetupEffectTransformDefaults(mdlMonster);
            //bug model
            mdlBug = Content.Load<Model>(".\\Models\\bug");
            mdlBugTransforms = SetupEffectTransformDefaults(mdlBug);
            //three armed monster model
            mdlThreeArms = Content.Load<Model>(".\\Models\\3arms");
            mdlThreeArmsTransforms = SetupEffectTransformDefaults(mdlThreeArms);
            //ground model
            mdlGround = Content.Load<Model>(".\\Models\\floor1");
            mdlGroundTransforms = SetupEffectTransformDefaults(mdlGround);
            //trapdoor model
            mdlTrapdoor = Content.Load<Model>(".\\Models\\trapdoor3");
            mdlTrapdoorTransforms = SetupEffectTransformDefaults(mdlTrapdoor);
            //wall model
            mdlWall = Content.Load<Model>(".\\Models\\wall3");
            mdlWallTransforms = SetupEffectTransformDefaults(mdlWall);
            //wall with door model
            mdlWall3 = Content.Load<Model>(".\\Models\\wallwdoor");
            mdlWall3Transforms = SetupEffectTransformDefaults(mdlWall3);
            //curtain model
            mdlCurtain = Content.Load<Model>(".\\Models\\curtain1");
            mdlCurtainTransforms = SetupEffectTransformDefaults(mdlCurtain);
            //key model
            mdlKey = Content.Load<Model>(".\\Models\\key");
            mdlKeyTransforms = SetupEffectTransformDefaults(mdlKey);
        }

        //Updates the game
        public override void Update(GameTime gameTime, bool otherScreenHasFocus, bool coveredByOtherScreen)
        {
            InitializeCamera();//Keeps an update of which camera is selected
            KeyControls();//Tracks the users input and updates the screen accordingly

            mdlPosition = cameraPosition + new Vector3(0, -60, 0);//Moves the model to match the camera postion plus an additional space for third person

            //boundingspheres created for the player and all the monsters
            BoundingSphere playerSphere = new BoundingSphere(mdlPosition, mdlChar.Meshes[0].BoundingSphere.Radius * GameConstants.PlayerBoundingSphereScale);
            BoundingSphere monsterSphere = new BoundingSphere(mdlMonsterPos, mdlMonster.Meshes[0].BoundingSphere.Radius * GameConstants.MonsterBoundingSphereScale);
            BoundingSphere seaMonsterSphere = new BoundingSphere(mdlSeaMonsterPos, mdlSeaMonster.Meshes[0].BoundingSphere.Radius * GameConstants.SeaMonsterBoundingSphereScale);
            BoundingSphere bugSphere = new BoundingSphere(mdlBugPos, mdlBug.Meshes[0].BoundingSphere.Radius * GameConstants.MonsterBoundingSphereScale);
            BoundingSphere threeArmsSphere = new BoundingSphere(mdlThreeArmsPos, mdlThreeArms.Meshes[0].BoundingSphere.Radius * GameConstants.MonsterBoundingSphereScale);

            //A loop to go through the keylist and check collisions between them against the player
            for (int k = 0; k < keyList.Length; k++)
             {
                 if (keyList[k].isActive)//checks if the key is active, if so, create bounding box
                 {
                     BoundingSphere keySphere = new BoundingSphere(keyList[k].position, mdlKey.Meshes[0].BoundingSphere.Radius * GameConstants.KeyBoundingSphereScale);
                     if (playerSphere.Intersects(keySphere))
                     {
                         keyList[k].isActive = false;//sets the key to false, bounding box removed
                         keyCollectGame++;//one added to collected keys
                         if (paused == false)
                         {
                             collsionSoundInstance.Play();//play collection sound
                         }
                     }
                 }
            }
            //If the player intersects with any monsters
            if (playerSphere.Intersects(monsterSphere) || playerSphere.Intersects(seaMonsterSphere) || playerSphere.Intersects(bugSphere) || playerSphere.Intersects(threeArmsSphere))
            {
                if (paused == false)
                {
                    hurtSoundInstance.Play();//play hurt sound
                }
                playerHealth -=0.3f;//take away from the players health
                if (playerHealth <= 0)//if health is 0 or less, load main menu
                {
                    LoadingScreen.Load(ScreenManager, true, ControllingPlayer.Value,new MainMenuScreen());
                }
            }

            base.Update(gameTime, otherScreenHasFocus, false);//update the game, if another screen has focus then don't update
        }

        //Processes the first person camera
        private void ProcessInput(float amount)
        {
            Vector3 moveVector = new Vector3(0, 0, 0);
            KeyboardState keyState = Keyboard.GetState();//gets the keyboard state
            MouseState currentMouseState = Mouse.GetState();//gets the mouse state
            GamePadState currentPadState = GamePad.GetState(PlayerIndex.One);//gets the gamepadstate

            //if the mouse has moved then find the differences in the x and y, the up and down rotation,
            //rotate the model, set the mouse back to the middle and the screen and update the view matrix
            if (currentMouseState != originalMouseState)
            {
                float xDifference = currentMouseState.X - originalMouseState.X;//calculate how much the mouse has moved on the x
                float yDifference = currentMouseState.Y - originalMouseState.Y;//calculate how much the mouse has moved on the y
                leftrightRot -= rotationSpeed * xDifference * amount;//left and right rotations
                mdlRotation -= rotationSpeed * xDifference * amount;//rotate the model on the x to match
                updownRot -= rotationSpeed * yDifference * amount;//rotations on the up and down
                Mouse.SetPosition(ScreenManager.GraphicsDevice.Viewport.Width / 2, ScreenManager.GraphicsDevice.Viewport.Height / 2);//set the mouse position back to middle
                UpdateViewMatrix();
            }

            //Controls to move the camera and player on the screen
            if (keyState.IsKeyDown(Keys.W) || GamePad.GetState(PlayerIndex.One).DPad.Up == ButtonState.Pressed)
                {moveVector += new Vector3(0, 0, -6);}
            if (keyState.IsKeyDown(Keys.S) || GamePad.GetState(PlayerIndex.One).DPad.Down == ButtonState.Pressed)
                {moveVector += new Vector3(0, 0, 6);}
            if (keyState.IsKeyDown(Keys.D) || GamePad.GetState(PlayerIndex.One).DPad.Right == ButtonState.Pressed)
                {moveVector += new Vector3(6, 0, 0);}
            if (keyState.IsKeyDown(Keys.A) || GamePad.GetState(PlayerIndex.One).DPad.Left == ButtonState.Pressed)
                {moveVector += new Vector3(-6, 0, 0);}

            AddToCameraPosition(moveVector * amount);
        }
       
        //calculates the rotation of the camera and camera position
        private void AddToCameraPosition(Vector3 vectorToAdd)
        {
            Matrix cameraRotation = Matrix.CreateRotationY(leftrightRot);
            Vector3 rotatedVector = Vector3.Transform(vectorToAdd, cameraRotation);
            cameraPosition += moveSpeed * rotatedVector;
            UpdateViewMatrix();
        }

        //calculates the updated view matrix after performing rotations and movement
        private void UpdateViewMatrix()
        {
            Matrix cameraRotation = Matrix.CreateRotationX(updownRot) * Matrix.CreateRotationY(leftrightRot);

            Vector3 cameraOriginalTarget = new Vector3(0, 0, -1);
            Vector3 cameraOriginalUpVector = new Vector3(0, 1, 0);

            Vector3 cameraRotatedTarget = Vector3.Transform(cameraOriginalTarget, cameraRotation);
            Vector3 cameraFinalTarget = cameraPosition + cameraRotatedTarget;

            Vector3 cameraRotatedUpVector = Vector3.Transform(cameraOriginalUpVector, cameraRotation);

            viewMatrix = Matrix.CreateLookAt(cameraPosition, cameraFinalTarget, cameraRotatedUpVector);
        }

        //Applies basicEffect to each model
        private Matrix[] SetupEffectTransformDefaults(Model myModel)
        {
            Matrix[] absoluteTransforms = new Matrix[myModel.Bones.Count];
            myModel.CopyAbsoluteBoneTransformsTo(absoluteTransforms);

            foreach (ModelMesh mesh in myModel.Meshes)
            {
                foreach (BasicEffect effect in mesh.Effects)
                {
                    effect.EnableDefaultLighting();
                    effect.Projection = projectionSelected;
                    effect.View = viewMatrixSelected;
                }
            }
            return absoluteTransforms;
        }

        //Draws the models
        public void DrawModel(Model model, Matrix modelTransform, Matrix[] absoluteBoneTransforms)
        {
            //Draw the model, a model can have multiple meshes, so loop
            foreach (ModelMesh mesh in model.Meshes)
            {
                //This is where the mesh orientation is set
                foreach (BasicEffect effect in mesh.Effects)
                {
                    effect.World = absoluteBoneTransforms[mesh.ParentBone.Index] * modelTransform;
                    effect.View = viewMatrixSelected;
                    effect.Projection = projectionSelected;
                    effect.FogEnabled = true;
                    effect.FogStart = 300f;
                    effect.FogEnd = 550f;
                }
                //Draw the mesh, will use the effects set above.
                mesh.Draw();
            }
        }

        //Write the GUI text to the screen
        private void writeText(string msg, Vector2 msgPos, Color msgColour)
        {
            spriteBatch.Begin();
            string output = msg;
            // Find the center of the string
            Vector2 FontOrigin = fontToUse.MeasureString(output) / 2;
            Vector2 FontPos = msgPos;
            // Draw the string
            spriteBatch.DrawString(fontToUse, output, FontPos, msgColour);
            spriteBatch.End();
        }

        //Draw the scene
        public override void Draw(GameTime gameTime)
        {
            ScreenManager.GraphicsDevice.Clear(ClearOptions.Target,Color.Black, 0, 0);//background default colour of black

            if (switchCamera == cameras.mainCamera)//if the camera is first person, switch matrices and draw
            {
                float timeDifference = (float)gameTime.ElapsedGameTime.TotalMilliseconds / 1000.0f;
                ProcessInput(timeDifference);//uses mouse controls
                viewMatrixSelected = viewMatrix;
                projectionSelected = projectionMatrix;
            }
            else if (switchCamera == cameras.topDownCamera) //if the camera is third person, switch the matrices and draw
            {
                UpdateCamera();
                float timeDifference = (float)gameTime.ElapsedGameTime.TotalMilliseconds / 1000.0f;
                ProcessInput(timeDifference);//uses mouse controls
                viewMatrixSelected = camera1.CamViewMatrix;
                projectionSelected = camera1.ProjectionMatrix;
            }

            DrawModels();//Call the draw models to loop through the models drawing them to the screen

            //Draw the GUI text
            writeText("Find and collect all the keys", new Vector2(50, 10), Color.White);
            writeText("Keys:" + keyCollectGame + "/4", new Vector2(50, 40), Color.White);
            writeText("Health:" + playerHealth.ToString("0"), new Vector2(50, 70), Color.White);
            base.Draw(gameTime);

            ScreenManager.GraphicsDevice.DepthStencilState = DepthStencilState.Default;//Switch from drawing 3D to drawing 2D
        }

        //Contains the models and their transforms
        //Since there are multiple keys, walls, doorways and curtains, create a list of each type to loop through
        public void  DrawModels()
        {
            if (switchCamera == cameras.topDownCamera)//only render the player when in third person camera
            {
                //player
                Matrix modelTransform = Matrix.CreateScale(0.15f, 0.15f, 0.15f) * Matrix.CreateRotationY(mdlRotation) * Matrix.CreateTranslation(mdlPosition);
                DrawModel(mdlChar, modelTransform, mdlCharTransforms);
            }
            //monster
            Matrix monsterTransform = Matrix.CreateScale(3.0f, 3.0f, 3.0f) * Matrix.CreateRotationY(-2.8f) * Matrix.CreateTranslation(mdlMonsterPos);
            DrawModel(mdlMonster, monsterTransform, mdlMonsterTransforms);

            //SeaMonster
            Matrix SeaMonsterTransform = Matrix.CreateScale(3.2f, 3.2f, 3.2f) * Matrix.CreateRotationY(-1.8f) * Matrix.CreateTranslation(mdlSeaMonsterPos);
            DrawModel(mdlSeaMonster, SeaMonsterTransform, mdlMonsterTransforms);

            //bug
            Matrix bugTransform = Matrix.CreateScale(1.0f, 1.0f, 1.0f) * Matrix.CreateTranslation(mdlBugPos);
            DrawModel(mdlBug, bugTransform, mdlBugTransforms);

            //three armed monster
            Matrix threeArmsTransform = Matrix.CreateScale(0.8f, 0.8f, 0.8f) * Matrix.CreateRotationY(-1.5f) * Matrix.CreateTranslation(mdlThreeArmsPos);
            DrawModel(mdlThreeArms, threeArmsTransform, mdlThreeArmsTransforms);

            //ground
            Matrix modelGroundTransform = Matrix.CreateScale(6.8f, 1.0f, 6.0f) * Matrix.CreateTranslation(-300, -80, 0);
            DrawModel(mdlGround, modelGroundTransform, mdlGroundTransforms);

            //roof
            Matrix modelRoofTransform = Matrix.CreateScale(6.8f, 1.0f, 6.0f) * Matrix.CreateTranslation(-300, 250, 0);
            DrawModel(mdlGround, modelRoofTransform, mdlGroundTransforms);

            //trapdoor
            Matrix trapDoorTransform = Matrix.CreateScale(2.5f, 2.5f, 2.5f) * Matrix.CreateRotationY(0.0f) * Matrix.CreateTranslation(-410, -78, -60);
            DrawModel(mdlTrapdoor, trapDoorTransform, mdlTrapdoorTransforms);

            //key
            for (int k = 0; k < keyList.Length; k++)
            {
                if (keyList[k].isActive == true)
                {
                    Matrix modelKeyTransform = Matrix.CreateScale(2.5f, 2.0f, 2.0f) * Matrix.CreateRotationY(-1.55f) * Matrix.CreateTranslation(keyList[k].position);
                    DrawModel(mdlKey, modelKeyTransform, mdlKeyTransforms);
                }
            }
            
            //walls
            for (int k = 0; k < wallList.Length; k++)
            {
                Matrix mdlWallTransform = Matrix.CreateScale(2.5f, 2.5f, 1.0f) * Matrix.CreateRotationY(wallList[k].rotation) * Matrix.CreateTranslation(wallList[k].position);
                    DrawModel(mdlWall, mdlWallTransform, mdlWallTransforms);
            }

            //doors
            for (int k = 0; k < doorList.Length; k++)
            {
                Matrix mdlDoorTransform = Matrix.CreateScale(2.5f, 2.5f, 1.0f) * Matrix.CreateRotationY(doorList[k].rotation) * Matrix.CreateTranslation(doorList[k].position);
                DrawModel(mdlWall3, mdlDoorTransform, mdlWall3Transforms);
            }

            //curtains
            for (int k = 0; k < curtainList.Length; k++)
            {
                Matrix mdlCurtainTransform = Matrix.CreateScale(2.5f, 2.0f, 1.0f) * Matrix.CreateRotationY(curtainList[k].rotation) * Matrix.CreateTranslation(curtainList[k].position);
                DrawModel(mdlCurtain, mdlCurtainTransform, mdlCurtainTransforms);
            }
        }
    }
}
