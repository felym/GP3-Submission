﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace lab6
{
    class GameConstants
    {
        public const float PlayerBoundingSphereScale = 0.63f;  
        public const float MonsterBoundingSphereScale = 1.1f; 
        public const float SeaMonsterBoundingSphereScale = 1.8f;
        public const float KeyBoundingSphereScale = 0.5f;
        public const int numWalls = 12;  
        public const int numDoors = 4;
        public const int keyNum = 4;
        public const int curtainNum = 4;
    }
}
