﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace lab6
{
    class Camera
    {
        Matrix camViewMatrix; //Cameras view
        Vector3 camPosition; //Position of Camera in world
        Vector3 camLookat; //Where the camera is looking or pointing at
        Vector3 camTransform; //Used for repositioning the camera after it has been rotated
        Matrix projectionMatrix;
        Matrix camRotationMatrix; //Rotation Matrix for camera to reflect movement around Y Axis
        float screenSize; //Finds out screen size
        float camRotationSpeed; //Defines the amount of rotation
        float camYaw;//Cumulative rotation on Y
        Vector3 inct;

        public float CamRotationSpeed
        {
            get { return this.camRotationSpeed; }
            set { this.camRotationSpeed = value; }
        }

        public float CamYaw
        {
            get { return this.camYaw; }
            set { this.camYaw = value; }
        }

        public Matrix CamViewMatrix
        {
            get { return this.camViewMatrix; }
            set { this.camViewMatrix = value; }
        }

        public Matrix CamRotationMatrix
        {
            get { return this.camRotationMatrix; }
            set { this.camRotationMatrix = value; }
        }

        public Vector3 CamPosition
        {
            get { return this.camPosition; }
            set { this.camPosition = value; }
        }

        public Vector3 Inct
        {
            get { return this.inct; }
            set { this.inct = value; }
        }

        public Vector3 CamTransform
        {
            get { return this.camTransform; }
            set { this.camTransform = value; }
        }

        public Vector3 CamLookat
        {
            get { return this.camLookat; }
            set { this.camLookat = value; }
        }

        public Matrix ProjectionMatrix
        {
            get { return this.projectionMatrix; }
        }


        public Camera(Viewport viewPort)
        {
            this.screenSize = ((float)viewPort.Width) / ((float)viewPort.Height);
            this.projectionMatrix = Matrix.CreatePerspectiveFieldOfView(MathHelper.ToRadians(45), screenSize, 1.0f, 1000.0f);
        }

    }


}
