﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;


namespace lab6
{
    struct Doors
    {
        public Vector3 position;
        public float rotation;
    }
}
